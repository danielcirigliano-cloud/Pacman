# Pac-Man Mundialista ONLINE — FIN-07 / Render

Este paquete está preparado para desplegarse como **Render Blueprint**.

## Estructura

```text
/
├── index.html
├── PacMan_Mundialista_Online_Server.py
├── render.yaml
├── requirements.txt
└── imagenes/
```

## Antes de subir a GitHub

Copiar `1.jpg` a `6.jpg` desde la instalación local del juego a `imagenes/`.
El paquete ya incluye `7.jpg` y los MP3 que estaban disponibles en la conversación.

## Subir a GitHub

1. Crear un repositorio nuevo, por ejemplo `pacman-mundialista-online`.
2. Subir **el contenido de esta carpeta a la raíz del repositorio**.
3. Confirmar que `render.yaml` quede en la raíz.

## Publicar en Render

1. Entrar a Render.
2. Elegir **New → Blueprint**.
3. Conectar el repositorio de GitHub.
4. Render detectará automáticamente `render.yaml`.
5. Aplicar/crear el Blueprint.

No es necesario completar manualmente Build Command, Start Command ni Health Check.

### Configuración incluida

- Runtime: Python
- Plan: Free
- Instancias: 1
- Build:
  `python -m py_compile PacMan_Mundialista_Online_Server.py`
- Start:
  `python PacMan_Mundialista_Online_Server.py --root .`
- Health:
  `/api/status`
- Auto deploy:
  cada commit

## Puerto

El servidor toma automáticamente la variable de entorno `PORT` de Render.
Si se ejecuta localmente y `PORT` no existe, usa `8095`.

## Importante para multiplayer

Las salas y partidas viven en memoria dentro del proceso Python.
Por eso FIN-07 debe ejecutarse con **1 instancia**. No aumentar `numInstances`
sin mover primero el estado de las salas a Redis/Key Value u otro almacenamiento compartido.

## Probar

Cuando Render finalice el deploy, abrir:

`https://<nombre-del-servicio>.onrender.com/`

Health check:

`https://<nombre-del-servicio>.onrender.com/api/status`

El mismo dominio sirve el HTML y el WebSocket; no hay que configurar una URL WebSocket aparte.
