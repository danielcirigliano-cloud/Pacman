# ARCHIVOS DE IMAGEN A AGREGAR

Antes de subir el repositorio a GitHub, copiá desde tu carpeta local actual:

    PacMan_Mundialista\imagenes\1.jpg
    PacMan_Mundialista\imagenes\2.jpg
    PacMan_Mundialista\imagenes\3.jpg
    PacMan_Mundialista\imagenes\4.jpg
    PacMan_Mundialista\imagenes\5.jpg
    PacMan_Mundialista\imagenes\6.jpg

dentro de la carpeta:

    imagenes/

`7.jpg` y los MP3 adjuntados en esta conversación ya están incluidos en este paquete.

La aplicación espera finalmente:

imagenes/
├── 1.jpg
├── 2.jpg
├── 3.jpg
├── 4.jpg
├── 5.jpg
├── 6.jpg
├── 7.jpg
├── musica.mp3
├── fantasma.mp3
├── gameover.mp3
├── Pacman comiendo.mp3
└── Pacman comiendo Vitamina.mp3
